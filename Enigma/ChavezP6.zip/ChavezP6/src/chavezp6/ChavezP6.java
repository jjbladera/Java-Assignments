/*File ChavezP6.java
 * 
 * Name:  Javier Chavez
 * Email: jchavez589@cnm.edu
 * P6 Enigma Class
 * 
 * CIS 2235 Java I
 */
package chavezp6;


public class ChavezP6{

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        EJFrame frame = new EJFrame();
        frame.setTitle("Javier C Program 6: Enigma Class");
        frame.setVisible(true);
    }

}
